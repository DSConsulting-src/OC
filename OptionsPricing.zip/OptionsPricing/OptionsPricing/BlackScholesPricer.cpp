#include <cmath>
#include <cfenv>
#include <iostream>
#include "BlackScholesPricer.h"

// Activate fenv for floating error detection. This has a slight performance overhead
// but has better chances to catch errors than defensive programming or relying on
// caller's code to check value pro-actively.
#pragma fenv_access(on)

namespace pricer {
    namespace blackscholes {

        namespace {
            // Compute Cumulative Normal Distribution.
            // We use 'N' as the function name to help cross-reference the formula specification.
            double N(const double x) {
                static const double SQRT_2 = std::sqrt(2);  // compute once for all
                return std::erfc(-x / SQRT_2) / 2;
            }

            std::string floatingErrorsAsText() {
                std::string errors;
                if (std::fetestexcept(FE_DIVBYZERO))
                    errors += "FE_DIVBYZERO";
                // We don't mind for INEXACT warnings
                // if (std::fetestexcept(FE_INEXACT))
                //    errors += "FE_INEXACT";
                if (std::fetestexcept(FE_INVALID))
                    errors += "FE_INVALID";
                if (std::fetestexcept(FE_OVERFLOW))
                    errors += "FE_OVERFLOW";
                if (std::fetestexcept(FE_UNDERFLOW))
                    errors += "FE_UNDERFLOW";
                return errors;
            }

            bool checkForArithmeticErrors() {
                // Additional checks for arithmetic errors due to incorrect inputs
                if (errno != 0) {
                    char buff[64];
                    strerror_s(buff, sizeof(buff), errno);
                    std::cerr
                        << "Pricer failed due to " << buff << " error. Please check parameters"
                        << std::endl;
                    return false;
                }
                if (math_errhandling & MATH_ERREXCEPT) {
                    if (fetestexcept(FE_DIVBYZERO | FE_INVALID | FE_OVERFLOW | FE_UNDERFLOW)) {
                        std::cerr
                            << "Pricer failed due to " << floatingErrorsAsText() <<" error. Please check parameters"
                            << std::endl;
                        return false;
                    }
                }
                return true;
            }
        }

        bool checkParams(BlackScholesModelParameters const& parameters) {
            return parameters.strikePrice != 0      // denominator for log(S/K)
                && parameters.timeToMaturity > 0;   // sqrt and denominator for d1 computation
        }

        // Implementation remark: we use floating exceptions to ensure errors such as
        // overflows or division by 0 are caught and reported.
        bool price(BlackScholesModelParameters const& parameters, OptionPremiums& premiums) {

            // reset previous errors ; ensures we properly catch arithmetic errors
            errno = 0;
            feclearexcept(FE_ALL_EXCEPT);

            // express as letters to match formula and help with readability
            const double S = parameters.stockPrice;
            const double K = parameters.strikePrice;
            const double t = parameters.timeToMaturity;
            const double s = parameters.standardDeviation;
            const double r = parameters.riskFreeInterestRate;

            const double sig_sqrt_t = s * std::sqrt(t);

            const double d1 = (log(S / K) + (r + s * s / 2) * t) / sig_sqrt_t;

            const double d2 = d1 - sig_sqrt_t;

            const double e_r_t = std::exp(-r * t);

            premiums.call = S * N(d1) - K * e_r_t * N(d2);
            premiums.put  = K * e_r_t * N(-d2) - S * N(-d1);

            return checkForArithmeticErrors();
        }
    }
}

std::ostream& operator<<(std::ostream& os, const pricer::blackscholes::OptionPremiums& optionPremiums) {
    os << "call: " << optionPremiums.call << " put: " << optionPremiums.put;
    return os;
}
