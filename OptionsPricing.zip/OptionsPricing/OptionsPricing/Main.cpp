#include <iomanip>
#include <iostream>

#include "BlackScholesPricer.h"

namespace bsp = pricer::blackscholes;

// Implement simple parameters parsing
// Nb: would handle erroneous inputs here (eg, using Boost.Program_options)
static bsp::BlackScholesModelParameters parseParams(int argc, const char * const argv[]) {
    bsp::BlackScholesModelParameters params = {
        std::strtod(argv[1], nullptr),
        std::strtod(argv[2], nullptr),
        std::strtod(argv[3], nullptr),
        std::strtod(argv[4], nullptr),
        std::strtod(argv[5], nullptr)
    };

    return params;
}

static void printUsage(const char* name) {
    std::cerr << "Usage: " << name 
        << "<stock price> "
        << "<strike price (required != 0)> "
        << "<time to maturity (years) (required > 0)> "
        << "<stock std dev> "
        << "<risk-free interest rate"
        << std::endl;
}

int main(int argc, const char * const argv[]) {

    if (argc != 1+5) {
        // Expect 6 arguments: program name and all 5 parameters to the pricing model
        printUsage(argv[0]);
        return 1;
    }

    const bsp::BlackScholesModelParameters modelParams = parseParams(argc, argv);

    // The pricing function has constraints on input values.
    // Implementation note: pricer implementation also handles floating point errors,
    // which makes this step somehow redundant (and possibly less exhaustive)
    if (!checkParams(modelParams)) {
        std::cerr << "Incorrect values" << std::endl;
        printUsage(argv[0]);
        return 2;
    }

    bsp::OptionPremiums premiums;
    if (!price(modelParams, premiums)) {
        std::cerr << "Pricing failed. Please check input values" << std::endl;
        printUsage(argv[0]);
        return 2;
    }

    std::cout << std::setprecision(5) << premiums << std::endl;

    return 0;
}
