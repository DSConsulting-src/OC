#pragma once

#include <iosfwd>

/// <summary>
/// Simple option pricer for European call and put options
/// </summary>
namespace pricer {
    namespace blackscholes {

        struct BlackScholesModelParameters {
            double stockPrice;
            double strikePrice;         /// restriction: != 0
            double timeToMaturity;      /// years (or fractions of). restriction: > 0
            double standardDeviation;   /// standard deviation of underlying stock
            double riskFreeInterestRate;
        };

        struct OptionPremiums {
            double call;
            double put;
        };

        /// <summary>
        /// Helper function to validate parameter values (see BlackScholesModelParameters)</see>
        /// </summary>
        /// <returns>
        /// false if strikePrice equals 0 or timeToMaturity is negative or 0
        /// </returns>
        bool checkParams(BlackScholesModelParameters const& parameters);

        /// <summary>
        /// Price option using the Black-Scholes model
        /// </summary>
        /// <param name="attributes">Model parameters</param>
        /// <param name="premiums">Computed premiums</param>
        /// <returns>
        /// true if premiums were properly computed ; 
        /// false if failed due to incorrect inputs (see checkParams)
        /// </returns>
        bool price(BlackScholesModelParameters const& parameters, OptionPremiums& premiums);
    }
}

std::ostream& operator<<(std::ostream& os, pricer::blackscholes::OptionPremiums const& optionPremiums);
