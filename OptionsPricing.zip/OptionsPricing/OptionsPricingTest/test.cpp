#include "pch.h"
#include "../OptionsPricing/BlackScholesPricer.h"

using pricer::blackscholes::BlackScholesModelParameters;
using pricer::blackscholes::OptionPremiums;

// Basic test, based on first example provided in the specification
TEST(BlackSholesOptionPricer, Sample1) {
    const BlackScholesModelParameters parameters = { 50.0, 55.0, 1, 0.2, 0.09 };
    const OptionPremiums expected = { 3.86167, 4.1279 };

    OptionPremiums actual;
    EXPECT_TRUE(price(parameters, actual)) << "Pricing failed due to arithmetic errors";

    EXPECT_NEAR(actual.call, expected.call, 0.0001);
    EXPECT_NEAR(actual.put,  expected.put,  0.0001);
}

// Basic test, based on second example provided in the specification
TEST(BlackSholesOptionPricer, Sample2) {
    const BlackScholesModelParameters parameters = { 64.0, 60.0, 180.0 / 365.0, 0.27, 0.045 };
    const OptionPremiums expected = { 7.7661, 2.4493 };

    OptionPremiums actual;
    EXPECT_TRUE(price(parameters, actual)) << "Pricing failed due to arithmetic errors";

    EXPECT_NEAR(actual.call, expected.call, 0.0001);
    EXPECT_NEAR(actual.put,  expected.put,  0.0001);
}

TEST(BlackSholesOptionPricer, ZeroStrike_InputErrorHandling) {
    const BlackScholesModelParameters parameters = {
        64.0,
        0.0,    // trigger a div0 error
        180.0 / 365.0,
        0.27,
        0.045
    };

    OptionPremiums actual;
    EXPECT_FALSE(price(parameters, actual)) << "Expected pricing would fail due to div by 0 error";
}

TEST(BlackSholesOptionPricer, ZeroMaturity_InputErrorHandling) {
    const BlackScholesModelParameters parameters = {
        64.0,
        60.0,
        0.0,    // maturity of 0 will result in div0 error
        0.27,
        0.045
    };

    OptionPremiums actual;
    EXPECT_FALSE(price(parameters, actual)) << "Expected pricing would fail due to arithmetic error";
}

TEST(BlackSholesOptionPricer, NegativeMaturity_InputErrorHandling) {
    const BlackScholesModelParameters parameters = {
        64.0,
        60.0,
        -1.0,    // sqrt will fail
        0.27,
        0.045
    };

    OptionPremiums actual;
    EXPECT_FALSE(price(parameters, actual)) << "Expected pricing would fail due to arithmetic error";
}

TEST(BlackSholesOptionPricer, HugeStockPrice_InputErrorHandling) {
    const BlackScholesModelParameters parameters = {
        HUGE_VAL,   // will fail due to overflow
        0.0,
        1.0,
        0.27,
        0.045
    };

    OptionPremiums actual;
    EXPECT_FALSE(price(parameters, actual)) << "Expected pricing would fail due to arithmetic error";
}
